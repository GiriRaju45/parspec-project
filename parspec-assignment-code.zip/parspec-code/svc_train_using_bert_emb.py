from transformers import BertTokenizer, BertModel
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import re
import os
import pandas as pd
import torch
import numpy as np
import joblib
from nltk.corpus import stopwords

# Load pre-trained BERT model and tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')

# Preprocessing functions
REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')
STOPWORDS = set(stopwords.words('english'))

def clean_text(text):
    text = re.sub(r'\d+(\.\d+)?', ' ', text)
    text = re.sub(r'\n+', '\n', text)
    text = re.sub(r'[^\w\s.,-]', ' ', text)
    text = re.sub(r'\s+([.,-])', r'\1', text)
    text = re.sub(r'\s+', ' ', text).strip()
    text = re.sub(r'[_\s]+', ' ', text)
    text = re.sub(r'[-\s]+', ' ', text)
    text = re.sub(r'[\.\,]+', ' ', text)
    text = re.sub(r'\b\w{1,2}\b', ' ', text)
    text = text.lower()
    text = REPLACE_BY_SPACE_RE.sub(' ', text)
    text = BAD_SYMBOLS_RE.sub('', text)
    text = ' '.join(word for word in text.split() if word not in STOPWORDS)
    cleaned_text = re.sub(r'\s+', ' ', text).strip()
    return cleaned_text

def chunk_text(document_text):
    chunks = []
    words = document_text.split()
    n = len(words) // 150
    if n < 1:
        n = 1
    for i in range(n):
        start = i * 150
        end = start + 200
        chunks.append(' '.join(words[start:end]))
    return chunks

def get_bert_cls_embedding(text):
    inputs = tokenizer(text, return_tensors='pt', truncation=True, padding=True)
    outputs = model(**inputs)
    cls_embedding = outputs.last_hidden_state[:, 0, :].squeeze().detach().numpy()
    return cls_embedding

def read_file(file_path, encoding='utf-8'):
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    except UnicodeDecodeError:
        print(f"Unicode decoding error for file: {file_path}")
        return None

# Load and prepare data
label_encoder = LabelEncoder()
train_df = pd.read_csv('processed_train_data.csv', sep='|')
train_df['target_label'] = label_encoder.fit_transform(train_df['target'])

train_texts = []
main_targets_train = []

text_dir = '/Users/guest1/Desktop/parspec-assignment/data/train_texts2'
for file in os.listdir(text_dir):
    pdf_name = file.replace('.txt', '.pdf')
    if not train_df.loc[train_df['file_name'] == pdf_name].empty:
        label = train_df.loc[train_df['file_name'] == pdf_name, 'target_label'].values[0]
        file_path = os.path.join(text_dir, file)
        data = read_file(file_path)
        if data:
            cleaned_text = clean_text(data)
            chunks = chunk_text(cleaned_text)
            for chunk in chunks:
                train_texts.append(chunk)
                main_targets_train.append(label)

train_embeddings = np.array([get_bert_cls_embedding(text) for text in train_texts])

test_txt_dir = 'data/test_texts'
test_texts = []
main_targets_test = []

test_df = pd.read_csv('processed_test_data.csv', sep='|')
test_df['target_label'] = label_encoder.transform(test_df['target'])

for file in os.listdir(test_txt_dir):
    pdf_name = file.replace('.txt', '.pdf')
    if not test_df.loc[test_df['file_name'] == pdf_name].empty:
        label = test_df.loc[test_df['file_name'] == pdf_name, 'target_label'].values[0]
        file_path = os.path.join(test_txt_dir, file)
        data = read_file(file_path)
        if data:
            cleaned_text = clean_text(data)
            chunks = chunk_text(cleaned_text)
            for chunk in chunks:
                test_texts.append(chunk)
                main_targets_test.append(label)

test_embeddings = np.array([get_bert_cls_embedding(text) for text in test_texts])
print('test:', main_targets_test)
print('train: ', main_targets_train)

# Split dataset into training and evaluation sets
X_train, X_test, y_train, y_test = train_embeddings, test_embeddings, main_targets_train, main_targets_test

# Define and train a classifier
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('clf', SVC(kernel='rbf'))
])

pipeline.fit(X_train, y_train)

# Evaluate the model
y_pred = pipeline.predict(X_test)
scores = accuracy_score(y_test, y_pred)
print(f"Accuracy: {scores:.4f}")

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, average='weighted')
recall = recall_score(y_test, y_pred, average='weighted')
f1 = f1_score(y_test, y_pred, average='weighted')

print(f"Accuracy: {accuracy:.4f}")
# print(f"Precision: {precision:.4f}")
# print(f"Recall: {recall:.4f}")
# print(f"F1-Score: {f1:.4f}")
# Save the model and label encoder
joblib.dump(pipeline, 'svc_text_classifier_chunked_text_model.pkl')
joblib.dump(label_encoder, 'svc_label_encoder.pkl')
